package org.slimarafa.svs_eleve;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SvsEleveApplicationTests {

	@Test
	void contextLoads() {
	}

}
