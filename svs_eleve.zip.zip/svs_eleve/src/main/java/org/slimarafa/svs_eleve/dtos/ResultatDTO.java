package org.slimarafa.svs_eleve.dtos;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.slimarafa.svs_eleve.entities.Periexam;
import org.slimarafa.svs_eleve.entities.Resultat;
import org.slimarafa.svs_eleve.mappers.EleveMapperImpl;
import org.springframework.beans.BeanUtils;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class ResultatDTO {
    private String idenelev;
    private String codeperiexam;
    private String moyeperiexam;
    private String rangperiexam;
    private String codedecicons;
    private String codesectori;
    private String obsecons;
    private String codeprix;
    private String moyeexamnati;
    private String codementexam;
    private String codeetab;
    private String codecondassi;
    private String datetransfert;
    private String etattransfert;
    private Timestamp date_insert;

}