package org.slimarafa.svs_eleve.mappers;

import org.slimarafa.svs_eleve.dtos.ClasseDTO;
import org.slimarafa.svs_eleve.entities.Classe;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
public class ClasseMapperImpl {
    public ClasseDTO fromClasse(Classe classe){
        ClasseDTO classeDTO = new ClasseDTO();
        BeanUtils.copyProperties(classe,classeDTO);
        return classeDTO;
    }

    public Classe fromClasseDTO(ClasseDTO classeDTO){
        Classe classe = new Classe();
        BeanUtils.copyProperties(classeDTO,classe);
        return classe;
    }

}
