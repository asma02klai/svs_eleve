package org.slimarafa.svs_eleve.mappers;

import lombok.AllArgsConstructor;
import org.slimarafa.svs_eleve.dtos.ResultatDTO;
import org.slimarafa.svs_eleve.entities.Resultat;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
//@AllArgsConstructor
//@Component
public class ResultatMapperImpl {
//    private EleveMapperImpl eleveMapper;
//    private PeriexamMapperImpl periexamMapper;
    public ResultatDTO fromResultat(Resultat resultat) {
        ResultatDTO resultatDTO = new ResultatDTO();
        BeanUtils.copyProperties(resultat, resultatDTO);
//        resultatDTO.setEleveDTO(eleveMapper.fromEleve(resultat.getEleve()));
//        resultatDTO.setPeriexamDTO(periexamMapper.fromPeriexam(resultat.getPeriexam()));
        return resultatDTO;
    }

    public Resultat fromResultatDTO(ResultatDTO resultatDTO) {
        Resultat resultat = new Resultat();
        BeanUtils.copyProperties(resultatDTO, resultat);
//        resultat.setEleve(eleveMapper.fromEleveDTO(resultatDTO.getEleveDTO()));
//        resultat.setPeriexam(periexamMapper.fromPeriexamDTO(resultatDTO.getPeriexamDTO()));
       return resultat;
    }
}


