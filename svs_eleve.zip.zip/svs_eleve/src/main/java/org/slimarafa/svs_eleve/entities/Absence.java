package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.*;

import java.sql.Date;

@Entity
public class Absence {
    @Id
    @Column(name = "idenelev")
    private String idenelev;

    @Column(name = "numeabse")
    private String numeabse;

    @Column(name = "codeperiexam")
    private String codeperiexam;

    @Column(name = "dateabse")
    @Temporal(TemporalType.DATE)
    private Date dateabse;

    @Column(name = "codetypeabse")
    private String codetypeabse;

    @Column(name = "nbrejourabse")
    private Integer nbrejourabse;

    @Column(name = "nbreheureabse")
    private Integer nbreheureabse;

    @Column(name = "nbreminureta")
    private Integer nbreminureta;

    @Column(name = "codecausabse")
    private String codecausabse;

    @Column(name = "codeetab")
    private String codeetab;


    public Absence() {
    }

    public String getIdenelev() {
        return idenelev;
    }

    public void setIdenelev(String idenelev) {
        this.idenelev = idenelev;
    }

    public String getNumeabse() {
        return numeabse;
    }

    public void setNumeabse(String numeabse) {
        this.numeabse = numeabse;
    }

    public String getCodeperiexam() {
        return codeperiexam;
    }

    public void setCodeperiexam(String codeperiexam) {
        this.codeperiexam = codeperiexam;
    }

    public Date getDateabse() {
        return dateabse;
    }

    public void setDateabse(Date dateabse) {
        this.dateabse = dateabse;
    }

    public String getCodetypeabse() {
        return codetypeabse;
    }

    public void setCodetypeabse(String codetypeabse) {
        this.codetypeabse = codetypeabse;
    }

    public Integer getNbrejourabse() {
        return nbrejourabse;
    }

    public void setNbrejourabse(Integer nbrejourabse) {
        this.nbrejourabse = nbrejourabse;
    }

    public Integer getNbreheureabse() {
        return nbreheureabse;
    }

    public void setNbreheureabse(Integer nbreheureabse) {
        this.nbreheureabse = nbreheureabse;
    }

    public Integer getNbreminureta() {
        return nbreminureta;
    }

    public void setNbreminureta(Integer nbreminureta) {
        this.nbreminureta = nbreminureta;
    }

    public String getCodecausabse() {
        return codecausabse;
    }

    public void setCodecausabse(String codecausabse) {
        this.codecausabse = codecausabse;
    }

    public String getCodeetab() {
        return codeetab;
    }

    public void setCodeetab(String codeetab) {
        this.codeetab = codeetab;
    }

}
