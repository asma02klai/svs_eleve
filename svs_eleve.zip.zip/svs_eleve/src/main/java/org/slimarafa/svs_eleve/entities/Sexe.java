package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity

public class Sexe {
    @Id
    private String codesexe;
    private String  libesexefr;
    private String libesexear;

}
