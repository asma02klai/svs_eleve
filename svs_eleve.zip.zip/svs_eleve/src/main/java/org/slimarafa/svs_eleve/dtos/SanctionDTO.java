package org.slimarafa.svs_eleve.dtos;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SanctionDTO {
        private String idenelev;
        private String numesanc ;
        private String codeperiexam ;
        private String datesanc ;
        private String codecatecaussanc ;
        private String codetypecaussanc ;
        private String codecaussanc;
        private String codetypesanc;
        private String proppar;
        private String codeetab;
        private String origcaussanc;
        private String nbrejoursanc;
        private String idimport ;
        private String datetransfert;
        private String etattransfert ;
        private String datedownload;
        //private String typesanc;
//        private String caussanc;
//        private String typecaussanc;
        private TypesancDTO typesancDTO;
        private CaussancDTO caussancDTO;
        private TypecaussancDTO typecaussancDTO;


}


