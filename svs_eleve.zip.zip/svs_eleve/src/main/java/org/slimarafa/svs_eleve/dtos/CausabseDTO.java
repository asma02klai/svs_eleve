package org.slimarafa.svs_eleve.dtos;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CausabseDTO {
    private String codecausabse;
    private String libecausabsear;
    private String libecausabsefr;
    private String codecausabsesy;

    // Constructeurs, getters et setters

    public String getCodecausabse() {
        return codecausabse;
    }

    public void setCodecausabse(String codecausabse) {
        this.codecausabse = codecausabse;
    }

    public String getLibecausabsear() {
        return libecausabsear;
    }

    public void setLibecausabsear(String libecausabsear) {
        this.libecausabsear = libecausabsear;
    }

    public String getLibecausabsefr() {
        return libecausabsefr;
    }

    public void setLibecausabsefr(String libecausabsefr) {
        this.libecausabsefr = libecausabsefr;
    }

    public String getCodecausabsesy() {
        return codecausabsesy;
    }

    public void setCodecausabsesy(String codecausabsesy) {
        this.codecausabsesy = codecausabsesy;
    }
}
