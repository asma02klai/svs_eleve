package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Eleve {
    @Id
    private String idenelev;
    private String prenelevar;
    private String nomelevar;
    private String nomelevfr;
    private String prenelevfr;
    private LocalDate datenaiselev;
    private String lieunaiselev;
    private String dateentretab;
    private String nomtute;
    private String prentute;
    private String lienpare;
    private String ruetute;
    private String codeposttute;
    private String villtute;
    private String teletute;
    private String datesortetab;

    @OneToOne(mappedBy = "eleve",fetch = FetchType.EAGER)
    private Inscription inscription;

    @ManyToOne
    @JoinColumns({
            @JoinColumn(name = "codeetab", referencedColumnName = "codeetab", insertable = false, updatable = false),
            @JoinColumn(name = "codetypeetab", referencedColumnName = "codetypeetab", insertable = false, updatable = false),
    })
    private Etablissement etablissement;

    @ManyToOne
    @JoinColumn(name = "codesexe")
    private Sexe sexe;

    @ManyToOne
    @JoinColumn(name = "codenati")
    private Nationalite nationalite;

   @OneToMany(mappedBy = "eleve")
   private List<Sanction> sanctions;

    @OneToOne(mappedBy = "eleve",fetch = FetchType.EAGER)
    private Resultat resultat;

}
