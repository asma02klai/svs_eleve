package org.slimarafa.svs_eleve.repositories;

import org.slimarafa.svs_eleve.entities.Sanction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SanctionRepository  extends JpaRepository<Sanction, String> {
    List<Sanction> getByIdenelev(String idenelev);
}
