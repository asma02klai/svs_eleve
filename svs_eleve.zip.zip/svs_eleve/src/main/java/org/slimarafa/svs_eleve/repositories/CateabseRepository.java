package org.slimarafa.svs_eleve.repositories;


import org.slimarafa.svs_eleve.entities.Cateabse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CateabseRepository extends JpaRepository<Cateabse, String> {
}
