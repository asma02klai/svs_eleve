package org.slimarafa.svs_eleve.mappers;

import org.slimarafa.svs_eleve.dtos.TypeabseDTO;
import org.slimarafa.svs_eleve.entities.Typeabse;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
public class TypeabseMapperImpl {
    public TypeabseDTO toDTO(Typeabse entity) {
        TypeabseDTO dto = new TypeabseDTO();
        BeanUtils.copyProperties(entity, dto);
        return dto;
    }

    public Typeabse toEntity(TypeabseDTO dto) {
        Typeabse entity = new Typeabse();
        BeanUtils.copyProperties(dto, entity);
        return entity;
    }
}
