package org.slimarafa.svs_eleve.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CateabseDTO {
    private String codecateabse;
    private String libecateabsear;
    private String libecateabsefr;

    // Constructeurs, getters et setters

    public String getCodecateabse() {
        return codecateabse;
    }

    public void setCodecateabse(String codecateabse) {
        this.codecateabse = codecateabse;
    }

    public String getLibecateabsear() {
        return libecateabsear;
    }

    public void setLibecateabsear(String libecateabsear) {
        this.libecateabsear = libecateabsear;
    }

    public String getLibecateabsefr() {
        return libecateabsefr;
    }

    public void setLibecateabsefr(String libecateabsefr) {
        this.libecateabsefr = libecateabsefr;
    }

}
