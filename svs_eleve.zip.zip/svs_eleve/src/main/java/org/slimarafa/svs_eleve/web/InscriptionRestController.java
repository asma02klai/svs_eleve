package org.slimarafa.svs_eleve.web;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slimarafa.svs_eleve.dtos.InscriptionDTO;
import org.slimarafa.svs_eleve.services.InscriptionService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@AllArgsConstructor
@Slf4j

public class InscriptionRestController {

    private InscriptionService inscriptionService;

    @GetMapping("inscriptions/{codeClass}")
    public List<InscriptionDTO> listEleveByClass(@PathVariable(name="codeClass") String codeClass){
        return inscriptionService.listElevesByClasse(codeClass);
    }
}
