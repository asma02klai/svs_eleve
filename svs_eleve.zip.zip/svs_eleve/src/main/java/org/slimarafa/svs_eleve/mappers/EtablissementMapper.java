package org.slimarafa.svs_eleve.mappers;

import lombok.AllArgsConstructor;
import org.slimarafa.svs_eleve.dtos.EtablissementDTO;
import org.slimarafa.svs_eleve.entities.Etablissement;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class EtablissementMapper {
    private DelegationMapper delegationMapper;
    private DreMapper dreMapper;
    private GouvernoratMapper gouvernoratMapper;

    public EtablissementDTO fromEtablissement(Etablissement etab){
        EtablissementDTO etabDTO = new EtablissementDTO();
        BeanUtils.copyProperties(etab,etabDTO);
        etabDTO.setDelegationDTO(delegationMapper.fromDelegation(etab.getDelegation()));
        etabDTO.setGouvernoratDTO(gouvernoratMapper.fromGouvernorat(etab.getGouvernorat()));
        etabDTO.setDreDTO(dreMapper.fromDre(etab.getDre()));
        return etabDTO;
    }

    public Etablissement fromEtablissementDTO(EtablissementDTO etabDTO){
        Etablissement etab = new Etablissement();
        BeanUtils.copyProperties(etabDTO,etab);
        etab.setDelegation(delegationMapper.fromDelegationDTO(etabDTO.getDelegationDTO()));
        etab.setGouvernorat(gouvernoratMapper.fromGouvernoratDTO(etabDTO.getGouvernoratDTO()));
        etab.setDre(dreMapper.fromDreDTO(etabDTO.getDreDTO()));
        return etab;
    }
}
