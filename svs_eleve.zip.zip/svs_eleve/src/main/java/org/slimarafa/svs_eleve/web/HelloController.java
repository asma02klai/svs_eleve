package org.slimarafa.svs_eleve.web;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class  HelloController {
    @GetMapping("/")
    public String greet(HttpServletRequest request) {
        return "welcome to Home Page" + request.getSession().getId() ;
    }

}
