package org.slimarafa.svs_eleve.services;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slimarafa.svs_eleve.dtos.EleveDTO;
import org.slimarafa.svs_eleve.entities.Eleve;
import org.slimarafa.svs_eleve.exceptions.EleveNotFoundException;
import org.slimarafa.svs_eleve.mappers.EleveMapperImpl;
import org.slimarafa.svs_eleve.repositories.EleveRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
@Slf4j
@AllArgsConstructor
public class EleveServiceImpl implements EleveService {
    private EleveRepository eleveRepository;
    private EleveMapperImpl dtoEleveMapper;


    @Override
    public List<EleveDTO> listEleves() {
        List<Eleve> eleves = eleveRepository.findAll();
        return eleves.stream().map(
                eleve -> dtoEleveMapper.fromEleve(eleve)).
                collect(Collectors.toList());
    }
    @Override
    public EleveDTO getEleve(String eleveId ) throws EleveNotFoundException {
     Eleve eleve=   eleveRepository.findById(eleveId).
                orElseThrow(()-> new EleveNotFoundException("eleve n'existe pas"));
    return dtoEleveMapper.fromEleve(eleve);
    }

    @Override
    public EleveDTO saveEleve(EleveDTO eleveDTO) {
       Eleve entity = new Eleve();
       BeanUtils.copyProperties(eleveDTO, entity);
       Eleve saved = eleveRepository.save(entity);

       EleveDTO result = new EleveDTO();
       BeanUtils.copyProperties(saved, result);
 return result;    }




    @Override
    public EleveDTO updateEleve(EleveDTO eleveDTO) {
        log.info("Saving new Eleve");
        Eleve eleve =dtoEleveMapper.fromEleveDTO(eleveDTO);
        Eleve savedEleve = eleveRepository.save(eleve);
        return dtoEleveMapper.fromEleve(savedEleve);
    }
    @Override
    public void deleteEleve(String eleveId){
        eleveRepository.deleteById(eleveId);
    }

}
