package org.slimarafa.svs_eleve.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class DreDTO {
    private String codedre;
    private String libedrear;
    private String libedrefr;
    private GouvernoratDTO gouvernoratDTO;

}
