package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
 public class Sanction {
    @Id
        private String idenelev;
        private String numesanc ;
       private String codeperiexam ;
        private String datesanc ;
       private String codecatecaussanc ;
        private String codetypecaussanc ;
        private String codecaussanc;
     private String codetypesanc;
       private String proppar;
        private String codeetab;
        private String origcaussanc;
        private String nbrejoursanc;
       private String idimport ;
       private String datetransfert;
      private String etattransfert ;
       private String datedownload;

    @ManyToOne
    private Eleve eleve;

    @ManyToOne
//    @JoinColumn(name = "codecaussanc", referencedColumnName = "codecaussanc")
    private Caussanc caussanc;

    @ManyToOne
//    @JoinColumn(name = "codetypesanc", referencedColumnName = "codetypesanc")
    private Typesanc typesanc;


  //  @ManyToOne
//    @JoinColumn(name = "codetypecaussanc", referencedColumnName = "codetypecaussanc")
   // private Typecaussanc typecaussanc;




    // Getters et setters nécessaires
    public Typesanc getTypesanc() {
        return typesanc;
    }

    public void setTypesanc(Typesanc typeSanc) {
        this.typesanc = typesanc;
    }

    public Caussanc getCaussanc() {
        return caussanc;
    }

    public void setCausesanc(Caussanc caussanc) {
        this.caussanc = caussanc;
    }


    public Typecaussanc getTypecaussanc() {
        Typecaussanc Typecaussanc = new Typecaussanc();
        return Typecaussanc ;
    }

//    public void setTypecaussanc(Typecaussanc typecaussanc) {
//         this.typecaussanc=typecaussanc;
//    }
}


