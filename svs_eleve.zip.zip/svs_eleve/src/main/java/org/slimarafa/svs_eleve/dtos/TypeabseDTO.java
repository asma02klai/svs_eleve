package org.slimarafa.svs_eleve.dtos;

public class TypeabseDTO {
    private String codetypeabse;
    private String libetypeabsear;
    private String libetypeabsefr;

    // Constructeurs, getters et setters

    public TypeabseDTO() {
    }

    public String getCodetypeabse() {
        return codetypeabse;
    }

    public void setCodetypeabse(String codetypeabse) {
        this.codetypeabse = codetypeabse;
    }

    public String getLibetypeabsear() {
        return libetypeabsear;
    }

    public void setLibetypeabsear(String libetypeabsear) {
        this.libetypeabsear = libetypeabsear;
    }

    public String getLibetypeabsefr() {
        return libetypeabsefr;
    }

    public void setLibetypeabsefr(String libetypeabsefr) {
        this.libetypeabsefr = libetypeabsefr;
    }
}
