package org.slimarafa.svs_eleve.dtos;

import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TypesancDTO {
    private String codetypesanc;
    private String libetypesancar;
    private String libetypesancfr;

}
