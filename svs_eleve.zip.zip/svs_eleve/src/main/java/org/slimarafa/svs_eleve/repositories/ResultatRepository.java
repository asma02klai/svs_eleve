package org.slimarafa.svs_eleve.repositories;

import jakarta.persistence.EntityNotFoundException;
import org.slimarafa.svs_eleve.entities.Inscription;
import org.slimarafa.svs_eleve.entities.Resultat;

import org.slimarafa.svs_eleve.entities.ResultatId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ResultatRepository extends JpaRepository<Resultat, ResultatId> {

      @Query("SELECT r FROM Resultat r WHERE r.idenelev = :idenelev AND r.codeperiexam = :codeperiexam")
    Resultat getEleveByResultat(@Param("idenelev") String idenelev,  @Param("codeperiexam") String codeperiexam);

   Optional<Resultat>getByIdenelevAndCodeperiexam(String idenelev, String codeperiexam);


}





