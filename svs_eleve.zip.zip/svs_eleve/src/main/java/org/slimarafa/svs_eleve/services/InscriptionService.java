package org.slimarafa.svs_eleve.services;

import org.slimarafa.svs_eleve.dtos.InscriptionDTO;
import org.slimarafa.svs_eleve.entities.Eleve;
import org.slimarafa.svs_eleve.entities.Inscription;

import java.util.List;

public interface InscriptionService {
    List<InscriptionDTO> listElevesByClasse(String codeclass );
}
