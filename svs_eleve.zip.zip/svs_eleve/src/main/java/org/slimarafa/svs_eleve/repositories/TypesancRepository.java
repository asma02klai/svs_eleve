package org.slimarafa.svs_eleve.repositories;

import org.slimarafa.svs_eleve.entities.Typesanc;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TypesancRepository  extends JpaRepository<Typesanc, String> {
}
