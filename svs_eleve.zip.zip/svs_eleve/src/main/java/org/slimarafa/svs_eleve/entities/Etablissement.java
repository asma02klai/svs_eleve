package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@IdClass(EtablissementId.class)
public class Etablissement {
    @Id @Column(length = 6)
    private String codeetab;
    @Id @Column(length = 2)
    private String codetypeetab;

    private String libeetabar;

    /*@ManyToOne
    @JoinColumn(name = "codetypeetab",
            foreignKey = @jakarta.persistence.ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private Typeetab typeetab;*/

    @ManyToOne
    @JoinColumn(name = "codegouv",
            foreignKey = @jakarta.persistence.ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private Gouvernorat gouvernorat;

    @ManyToOne
    @JoinColumn(name = "codedele",
            foreignKey = @jakarta.persistence.ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private Delegation delegation;

    @ManyToOne
    @JoinColumn(name = "codedre",
            foreignKey = @jakarta.persistence.ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private Dre dre;

    @OneToMany(mappedBy = "etablissement",fetch = FetchType.EAGER)
    private List<Eleve> eleves;

    @OneToMany(mappedBy = "etabInscri")
    private List<Inscription> inscriptions;

    @OneToMany(mappedBy = "etab")
    private List<Classe> classes;



}

