package org.slimarafa.svs_eleve.entities;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Typecaussanc {
    @Id
    private String codetypecaussanc ;
    private String libetypecaussancar;
    private String libetypecaussancfr;
    private String codecatecaussanc;


    @OneToMany(mappedBy = "typecaussanc")
    private List<Caussanc> caussancs;

//    @OneToMany(mappedBy = "typecaussanc")
//    private List<Sanction> sanctions;
}


