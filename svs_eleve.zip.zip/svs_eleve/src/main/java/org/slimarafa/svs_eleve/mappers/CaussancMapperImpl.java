package org.slimarafa.svs_eleve.mappers;
import org.slimarafa.svs_eleve.dtos.CaussancDTO;
import org.slimarafa.svs_eleve.entities.Caussanc;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

@Component
public class CaussancMapperImpl {
    public CaussancDTO fromCaussanc(Caussanc caussanc){
        CaussancDTO caussancDTO = new CaussancDTO();
//        caussancDTO.setCodecaussanc(caussanc.getCodecaussanc());
//        caussancDTO.setLibecaussancfr(caussanc.getLibecaussancfr());
     BeanUtils.copyProperties(caussanc, caussancDTO);
        return caussancDTO;
    }

   public Caussanc fromCaussancDTO(CaussancDTO caussancDTO){
        Caussanc caussanc = new Caussanc();
        BeanUtils.copyProperties(caussancDTO,caussanc);
        return caussanc;
    }
}
