package org.slimarafa.svs_eleve.repositories;


import org.slimarafa.svs_eleve.entities.Nivescol;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NivescolRepository  extends
        JpaRepository<Nivescol,String> {
}