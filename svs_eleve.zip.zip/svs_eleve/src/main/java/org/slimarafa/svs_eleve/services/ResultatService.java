package org.slimarafa.svs_eleve.services;

import org.slimarafa.svs_eleve.dtos.ResultatDTO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ResultatService {

   List<ResultatDTO> getElevesByResultat(String idenelev, String codeperiexam);



}

