package org.slimarafa.svs_eleve;

import org.slimarafa.svs_eleve.entities.Etablissement;
import org.slimarafa.svs_eleve.entities.EtablissementId;
import org.slimarafa.svs_eleve.repositories.EtablissementRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Optional;

@SpringBootApplication
public class SvsEleveApplication {

    public static void main(String[] args) {
        SpringApplication.run(SvsEleveApplication.class, args);
    }

    @Bean
    CommandLineRunner start(EtablissementRepository etablissementRepository) {
        return args -> {
            EtablissementId etabId= new EtablissementId("614004","40");
           Etablissement etab= etablissementRepository.findById(etabId).orElse(null);
            if(etab!=null){
                System.out.println("***************************************");
               System.out.println(etab.getCodeetab()+"-"+etab.getCodetypeetab());
                System.out.println(etab.getLibeetabar());
            }
        };
    }
}
