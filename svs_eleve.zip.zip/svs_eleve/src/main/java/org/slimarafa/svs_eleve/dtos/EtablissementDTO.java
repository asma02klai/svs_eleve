package org.slimarafa.svs_eleve.dtos;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.slimarafa.svs_eleve.entities.*;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class EtablissementDTO {

    private String codeetab;
    private String codetypeetab;
    private String libeetabar;


    private GouvernoratDTO gouvernoratDTO;

    private DelegationDTO delegationDTO;

   private DreDTO dreDTO;





}

