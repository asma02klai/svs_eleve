package org.slimarafa.svs_eleve.mappers;

import org.slimarafa.svs_eleve.dtos.CausabseDTO;
import org.slimarafa.svs_eleve.entities.Causabse;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
public class CausabseMapperImpl {
    public CausabseDTO toDTO(Causabse entity) {
        CausabseDTO dto = new CausabseDTO();
        BeanUtils.copyProperties(entity, dto);
        return dto;
    }

    public Causabse toEntity(CausabseDTO dto) {
        Causabse entity = new Causabse();
        BeanUtils.copyProperties(dto, entity);
        return entity;
    }
}
