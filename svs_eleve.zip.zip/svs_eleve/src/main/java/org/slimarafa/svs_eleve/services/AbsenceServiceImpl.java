package org.slimarafa.svs_eleve.services;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slimarafa.svs_eleve.dtos.AbsenceDTO;
import org.slimarafa.svs_eleve.entities.Absence;
import org.slimarafa.svs_eleve.entities.Cateabse;
import org.slimarafa.svs_eleve.entities.Causabse;
import org.slimarafa.svs_eleve.entities.Typeabse;
import org.slimarafa.svs_eleve.repositories.AbsenceRepository;
import org.slimarafa.svs_eleve.repositories.CateabseRepository;
import org.slimarafa.svs_eleve.repositories.CausabseRepository;
import org.slimarafa.svs_eleve.repositories.TypeabseRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
@Slf4j
@AllArgsConstructor
public class AbsenceServiceImpl implements AbsenceService {

    @Autowired
    private AbsenceRepository absenceRepository;
    private TypeabseRepository typeabseRepository;
    private CausabseRepository causabseRepository;
    private CateabseRepository cateabseRepository;

    @Override
    public List<AbsenceDTO> getAbsencesByIdEleve(String idenelev) {
        List<Absence> absences = absenceRepository.findByIdenelev(idenelev);
        List<AbsenceDTO> result = new ArrayList<>();

        for (Absence absence : absences) {
            AbsenceDTO dto = new AbsenceDTO();
            BeanUtils.copyProperties(absence, dto);

            // Ajout des détails typeabse
            Typeabse typeabse = typeabseRepository.findById(absence.getCodetypeabse()).orElse(null);
            if (typeabse != null) {
                dto.setLibetypeabsefr(typeabse.getLibetypeabsefr());
            }

            // Ajout des détails causabse
            Causabse causabse = causabseRepository.findById(absence.getCodecausabse()).orElse(null);
            if (causabse != null) {
                dto.setLibecausabsefr(causabse.getLibecausabsefr());

                // Ajout des détails cateabse via causabse
                Cateabse cateabse = cateabseRepository.findById(causabse.getCodecausabsesy()).orElse(null);
                if (cateabse != null) {
                    dto.setLibecateabsefr(cateabse.getLibecateabsefr());
                }
            }

            result.add(dto);
        }

        return result;
    }
}

