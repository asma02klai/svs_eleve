package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Delegation {
    @Id
    private String codedele;
    private String libedelear;
    private String libedelefr;

    @ManyToOne
    @JoinColumn(name = "codegouv")
    private Gouvernorat gouvernorat;

    @OneToMany(mappedBy = "delegation")
    private List<Etablissement> etabdelegs;

}
