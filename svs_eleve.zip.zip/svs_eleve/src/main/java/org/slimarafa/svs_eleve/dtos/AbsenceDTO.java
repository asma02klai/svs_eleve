package org.slimarafa.svs_eleve.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AbsenceDTO {
 private String idenelev;
private String numeabse;
private String codeperiexam;
private Date dateabse;
private String codetypeabse;
private Integer nbrejourabse;
private Integer nbreheureabse;
private Integer nbreminureta;
private String codecausabse;
private String codeetab;
    private String libetypeabsefr;
    private String libecausabsefr;
    private String libecateabsefr;

    public String getIdenelev() {
        return idenelev;
    }

    public void setIdenelev(String idenelev) {
        this.idenelev = idenelev;
    }

    public String getNumeabse() {
        return numeabse;
    }

    public void setNumeabse(String numeabse) {
        this.numeabse = numeabse;
    }

    public String getCodeperiexam() {
        return codeperiexam;
    }

    public void setCodeperiexam(String codeperiexam) {
        this.codeperiexam = codeperiexam;
    }

    public Date getDateabse() {
        return dateabse;
    }

    public void setDateabse(Date dateabse) {
        this.dateabse = dateabse;
    }

    public String getCodetypeabse() {
        return codetypeabse;
    }

    public void setCodetypeabse(String codetypeabse) {
        this.codetypeabse = codetypeabse;
    }

    public Integer getNbrejourabse() {
        return nbrejourabse;
    }

    public void setNbrejourabse(Integer nbrejourabse) {
        this.nbrejourabse = nbrejourabse;
    }

    public Integer getNbreheureabse() {
        return nbreheureabse;
    }

    public void setNbreheureabse(Integer nbreheureabse) {
        this.nbreheureabse = nbreheureabse;
    }

    public Integer getNbreminureta() {
        return nbreminureta;
    }

    public void setNbreminureta(Integer nbreminureta) {
        this.nbreminureta = nbreminureta;
    }

    public String getCodecausabse() {
        return codecausabse;
    }

    public void setCodecausabse(String codecausabse) {
        this.codecausabse = codecausabse;
    }

    public String getCodeetab() {
        return codeetab;
    }

    public void setCodeetab(String codeetab) {
        this.codeetab = codeetab;
    }

    public void setLibetypeabsefr(String libetypeabsefr) {
        this.libetypeabsefr = libetypeabsefr ;
    }

    public void setLibecausabsefr(String libecausabsefr) {
        this.libecausabsefr = libecausabsefr;
    }

    public void setLibecateabsefr(String libecateabsefr) {
        this.libecateabsefr = libecateabsefr;
    }
}