package org.slimarafa.svs_eleve.web;


import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slimarafa.svs_eleve.dtos.EleveDTO;
import org.slimarafa.svs_eleve.dtos.ResultatDTO;
import org.slimarafa.svs_eleve.exceptions.EleveNotFoundException;
import org.slimarafa.svs_eleve.exceptions.ResultatNotFoundException;
import org.slimarafa.svs_eleve.services.InscriptionService;
import org.slimarafa.svs_eleve.services.ResultatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/resultat")
@AllArgsConstructor
@Slf4j

public class ResultatRestController {
    private ResultatService resultatService;

    @GetMapping("/{idenelev}/{codeperiexam}")
    public List<ResultatDTO> getEleveByResultat(
            @PathVariable String idenelev,
            @PathVariable String codeperiexam) throws ResultatNotFoundException {
        return resultatService.getElevesByResultat(idenelev, codeperiexam);
    }
}



//@RestController
//@NoArgsConstructor
//@AllArgsConstructor
//public class ResultatRestController {
//
//    private ResultatService resultatService;
//
//    @GetMapping("/resultat/{idenelev}/{codeperiexam}")
//    public List<ResultatDTO> listEleveByResultat(
//            @PathVariable(name="idenelev") String idenelev,
//            @PathVariable(name="codeperiexam") String codeperiexam){
//        return resultatService.findElevesByResultat( idenelev ,codeperiexam);
//