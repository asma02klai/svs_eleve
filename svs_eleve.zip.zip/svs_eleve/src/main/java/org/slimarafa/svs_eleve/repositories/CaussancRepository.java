package org.slimarafa.svs_eleve.repositories;

import org.slimarafa.svs_eleve.entities.Caussanc;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CaussancRepository extends JpaRepository<Caussanc, String> {
}
