package org.slimarafa.svs_eleve.repositories;

import org.slimarafa.svs_eleve.entities.Etablissement;
import org.slimarafa.svs_eleve.entities.EtablissementId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EtablissementRepository  extends
        JpaRepository<Etablissement, EtablissementId> {

}
