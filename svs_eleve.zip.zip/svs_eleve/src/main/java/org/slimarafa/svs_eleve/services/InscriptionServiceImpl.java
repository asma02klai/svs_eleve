package org.slimarafa.svs_eleve.services;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slimarafa.svs_eleve.dtos.InscriptionDTO;
import org.slimarafa.svs_eleve.entities.Classe;
import org.slimarafa.svs_eleve.entities.Inscription;
import org.slimarafa.svs_eleve.mappers.InscriptionMapperImp;
import org.slimarafa.svs_eleve.repositories.ClasseRepository;
import org.slimarafa.svs_eleve.repositories.InscriptionRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
@Slf4j
@AllArgsConstructor
public class InscriptionServiceImpl implements InscriptionService {
    private InscriptionRepository inscriptionRepository;
    private ClasseRepository classeRepository;
    private InscriptionMapperImp inscriMapper;

    @Override
    public List<InscriptionDTO> listElevesByClasse(String codeclass) {
        Classe classe = classeRepository.findById(codeclass).orElse(null);
        List<Inscription> inscriptions = new ArrayList<>();

        if (classe != null) {
            inscriptions =
                    inscriptionRepository.findByClasse(codeclass);
        }
        List<InscriptionDTO> inscriptionDTOs = new ArrayList<>();
        inscriptionDTOs = inscriptions.stream().map(inscri ->
                inscriMapper.fromInscription(inscri)
        ).collect(Collectors.toList());

        return inscriptionDTOs;
    }


}
