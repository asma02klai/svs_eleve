package org.slimarafa.svs_eleve.repositories;

import org.slimarafa.svs_eleve.entities.Classe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClasseRepository extends
        JpaRepository<Classe,String> {
}
