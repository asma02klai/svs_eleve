package org.slimarafa.svs_eleve.mappers;

import lombok.AllArgsConstructor;
import org.slimarafa.svs_eleve.dtos.PeriexamDTO;
import org.slimarafa.svs_eleve.entities.Periexam;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class PeriexamMapperImpl {

    public PeriexamDTO fromPeriexam(Periexam periexam) {
        PeriexamDTO periexamDTO = new PeriexamDTO();
        BeanUtils.copyProperties(periexam, periexamDTO);
        return periexamDTO;
    }

    public Periexam fromPeriexamDTO(PeriexamDTO periexamDTO) {
        Periexam periexam = new Periexam();
        BeanUtils.copyProperties(periexamDTO, periexam);
        return periexam;
    }


}
