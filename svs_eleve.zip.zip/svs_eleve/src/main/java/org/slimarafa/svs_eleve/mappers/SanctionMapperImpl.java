package org.slimarafa.svs_eleve.mappers;
import org.slimarafa.svs_eleve.dtos.SanctionDTO;
import org.slimarafa.svs_eleve.entities.Sanction;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SanctionMapperImpl {
    private TypesancMapperImpl typesancMapper;
    private  CaussancMapperImpl caussancMapper;
  //  private TypecaussancMapperImpl typecaussancMapper;


    public SanctionDTO fromSanction(Sanction sanction) {
        SanctionDTO sanctionDTO = new SanctionDTO();
        BeanUtils.copyProperties(sanction, sanctionDTO);
//        sanctionDTO.setTypesancDTO(typesancMapper.fromTypesanc(sanction.getTypesanc()));
//        sanctionDTO.setCaussancDTO(caussancMapper.fromCaussanc(sanction.getCaussanc()));
//        sanctionDTO.setTypecaussancDTO(typecaussancMapper.fromTypecaussanc(sanction.getTypecaussanc()));
        return sanctionDTO;
    }

    public Sanction fromSanctionDTO(SanctionDTO sanctionDTO) {
        Sanction sanction = new Sanction();
        BeanUtils.copyProperties(sanctionDTO, sanction);
//        sanction.setTypesanc(typesancMapper.fromTypesancDTO(sanctionDTO.getTypesancDTO()));
//        sanction.setCaussanc(caussancMapper.fromCaussancDTO(sanctionDTO.getCaussancDTO()));
//        sanction.setTypecaussanc(typecaussancMapper.fromTypecaussancDTO(sanctionDTO.getTypecaussancDTO()));
        return sanction;
    }
}


