package org.slimarafa.svs_eleve.repositories;


import org.slimarafa.svs_eleve.entities.Typeabse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TypeabseRepository extends JpaRepository<Typeabse, String> {
}

