package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.Embeddable;

import java.io.Serializable;
import java.util.Objects;
@Embeddable
public class ResultatId implements Serializable {
    private  String idenelev;
    private  String codeperiexam;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ResultatId that = (ResultatId) o;
        return Objects.equals(idenelev, that.idenelev) && Objects.equals(codeperiexam, that.codeperiexam);
    }

   @Override
    public int hashCode() {
        return Objects.hash(idenelev, codeperiexam);
    }
}



