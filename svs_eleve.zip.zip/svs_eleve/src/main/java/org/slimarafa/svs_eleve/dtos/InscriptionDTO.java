package org.slimarafa.svs_eleve.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.slimarafa.svs_eleve.entities.Classe;
import org.slimarafa.svs_eleve.entities.Eleve;
import org.slimarafa.svs_eleve.entities.Etablissement;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InscriptionDTO {
    private EleveDTO eleveDTO;
    private ClasseDTO classeDTO;
    private EtablissementDTO etabInscriDto;
    private  String numeordr;
    private  String etatinsc;


}
