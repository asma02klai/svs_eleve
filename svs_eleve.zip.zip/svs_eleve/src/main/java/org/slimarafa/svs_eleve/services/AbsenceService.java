package org.slimarafa.svs_eleve.services;

import org.slimarafa.svs_eleve.dtos.AbsenceDTO;

import java.util.List;

public interface AbsenceService {
    List<AbsenceDTO> getAbsencesByIdEleve(String idenelev);
}
