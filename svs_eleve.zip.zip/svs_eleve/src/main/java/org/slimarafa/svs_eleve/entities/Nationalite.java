package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Nationalite {
    @Id
    private String codenati;
    private String  libenatifr;
    private String libenatiar;
}
