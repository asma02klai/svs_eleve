package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor

@Entity
public class Classe {
    @Id
    private String codeclas;
    private String annescol;
    private String libeclasar;
    private String libeclasfr;

    @ManyToOne
    @JoinColumns({
            @JoinColumn(name = "codeetab", referencedColumnName = "codeetab", insertable = false, updatable = false),
            @JoinColumn(name = "codetypeetab", referencedColumnName = "codetypeetab", insertable = false, updatable = false),
    })
    private Etablissement etab;

    @OneToMany(mappedBy = "classe")
    private List<Inscription> eleves;

    @ManyToOne
    @JoinColumn(name = "codenive")
    private Nivescol nivescol;

}

