package org.slimarafa.svs_eleve.repositories;

import org.slimarafa.svs_eleve.entities.Classe;
import org.slimarafa.svs_eleve.entities.Inscription;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface InscriptionRepository extends
        JpaRepository<Inscription, String> {
    @Query(
            value = "SELECT *\n" +
                    "FROM inscription*\n" +
                    "where inscription.codeclas=:codeclass\n" +
                    "ORDER BY inscription.numeordr::INTEGER",
            nativeQuery = true)
    List<Inscription> findByClasse(@Param("codeclass") String codeclasse);
}
