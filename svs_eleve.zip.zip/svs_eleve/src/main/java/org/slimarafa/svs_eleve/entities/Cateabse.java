package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Cateabse {


        @Id
        @Column(name = "codecateabse")
        private String codecateabse;

        @Column(name = "libecateabsear")
        private String libecateabsear;

        @Column(name = "libecateabsefr")
        private String libecateabsefr;

        // Constructeurs, getters et setters

        public Cateabse() {
        }

    public String getLibecateabsefr() {
                return libecateabsefr ;
    }
}
