package org.slimarafa.svs_eleve.mappers;

import lombok.AllArgsConstructor;
import org.slimarafa.svs_eleve.dtos.DelegationDTO;
import org.slimarafa.svs_eleve.entities.Delegation;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class DelegationMapper {
    private GouvernoratMapper gouvernoratMapper;
    public DelegationDTO fromDelegation(Delegation delegation){
        DelegationDTO delegationDTO = new DelegationDTO();
        BeanUtils.copyProperties(delegation,delegationDTO);
        delegationDTO.setGouvernoratDTO(gouvernoratMapper.fromGouvernorat(delegation.getGouvernorat()));
        return delegationDTO;
    }

    public Delegation fromDelegationDTO(DelegationDTO delegationDTO){
        Delegation delegation = new Delegation();
        BeanUtils.copyProperties(delegationDTO,delegation);
        delegation.setGouvernorat(gouvernoratMapper.fromGouvernoratDTO(delegationDTO.getGouvernoratDTO()));
        return delegation;
    }
}
