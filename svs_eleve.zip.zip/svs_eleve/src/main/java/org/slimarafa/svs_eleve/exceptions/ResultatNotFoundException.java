package org.slimarafa.svs_eleve.exceptions;

public class ResultatNotFoundException extends RuntimeException {
  public ResultatNotFoundException(String message) {

    super(message);
  }
}
