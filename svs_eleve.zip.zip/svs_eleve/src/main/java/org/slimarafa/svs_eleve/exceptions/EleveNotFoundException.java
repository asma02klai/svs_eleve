package org.slimarafa.svs_eleve.exceptions;

public class EleveNotFoundException  extends Throwable  {
    public EleveNotFoundException(String s) {
        super(s);
    }
}
