package org.slimarafa.svs_eleve.web;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slimarafa.svs_eleve.dtos.AbsenceDTO;
import org.slimarafa.svs_eleve.services.AbsenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@AllArgsConstructor
@Slf4j
public class AbsenceRestContoller {
    @Autowired
    private AbsenceService absenceService;

    @GetMapping("/eleve/{idenelev}")
    public ResponseEntity<List<AbsenceDTO>> getAbsencesByIdEleve(@PathVariable String idenelev) {
        List<AbsenceDTO> absences = absenceService.getAbsencesByIdEleve(idenelev);
        return ResponseEntity.ok(absences);
    }
}

