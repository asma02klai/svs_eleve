package org.slimarafa.svs_eleve.exceptions;

public class SanctionNotFoundException extends RuntimeException {
    public SanctionNotFoundException(String message) {
        super(message);
    }
}
