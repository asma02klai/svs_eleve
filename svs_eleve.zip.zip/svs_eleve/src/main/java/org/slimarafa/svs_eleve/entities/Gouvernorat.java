package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Gouvernorat {
    @Id
    private String codegouv;
    private String libegouvar;
    private String libegouvfr;

    @OneToMany(mappedBy = "gouvernorat")
    private List<Etablissement> etabgouvs;

    @OneToMany(mappedBy = "gouvernorat")
    private List<Delegation> delegations;

    @OneToMany(mappedBy = "gouvernorat")
    private List<Dre> dres;


}
