
package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Periexam {
    @Id
    private String codeperiexam;
    private String libeperiexamar;
    private String libeperiexamfr;
    private String coefperiexam;

    @OneToMany(mappedBy = "periexam")
    private List<Resultat> resultats;
}
