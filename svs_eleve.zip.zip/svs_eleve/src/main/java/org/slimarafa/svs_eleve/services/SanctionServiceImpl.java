package org.slimarafa.svs_eleve.services;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slimarafa.svs_eleve.dtos.InscriptionDTO;
import org.slimarafa.svs_eleve.dtos.SanctionDTO;
import org.slimarafa.svs_eleve.entities.Classe;
import org.slimarafa.svs_eleve.entities.Eleve;
import org.slimarafa.svs_eleve.entities.Inscription;
import org.slimarafa.svs_eleve.entities.Sanction;
import org.slimarafa.svs_eleve.exceptions.SanctionNotFoundException;
import org.slimarafa.svs_eleve.mappers.SanctionMapperImpl;
import org.slimarafa.svs_eleve.repositories.EleveRepository;
import org.slimarafa.svs_eleve.repositories.SanctionRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
@Slf4j
@AllArgsConstructor
public class SanctionServiceImpl implements SanctionService {
    private SanctionRepository sanctionRepository;
    private SanctionMapperImpl sanctionMapper;
    private EleveRepository eleveRepository;


    @Override
    public List<SanctionDTO> getSanctionsByEleve(String idenelev) {
        Eleve eleve = eleveRepository.getByIdenelev(idenelev);
        List<Sanction> sanctions = new ArrayList<>();

        if (eleve != null) {
            sanctions =
                    sanctionRepository.getByIdenelev(idenelev);
        }

        List<SanctionDTO> sanctionDTOs = new ArrayList<>();
        sanctionDTOs = sanctions.stream().map(sanction ->
                sanctionMapper.fromSanction(sanction)
        ).collect(Collectors.toList());
        return sanctionDTOs;


    }

    @Override
    public SanctionDTO saveSanction(SanctionDTO sanctionDTO) {
        Sanction sanction = sanctionMapper.fromSanctionDTO(sanctionDTO);
        return sanctionMapper.fromSanction(sanctionRepository.save(sanction));

    }
    @Override
    public SanctionDTO updateSanction(SanctionDTO sanctionDTO) {
        Sanction existing = sanctionRepository.findById(sanctionDTO.getNumesanc())
                .orElseThrow(() -> new RuntimeException("Sanction not found"));
        Sanction updated = sanctionMapper.fromSanctionDTO(sanctionDTO);
        updated.setIdenelev(existing.getIdenelev()); // conserver idEleve s'il ne change pas
        return sanctionMapper.fromSanction(sanctionRepository.save(updated));
    }

    @Override
    public void deleteSanction(String numesanc) {
        sanctionRepository.deleteById(numesanc);

    }
}


