package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.sql.Timestamp;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@IdClass(ResultatId.class)
public class Resultat {
    @Id
    private String idenelev;
    @Id
    private String codeperiexam;
    private String moyeperiexam;
    private String rangperiexam;
    private String codedecicons;
    private String codesectori;
    private String obsecons;
    private String codeprix;
    private String moyeexamnati;
    private String codementexam;
    private String codeetab;
    private String codecondassi;
    private String datetransfert;
    private String etattransfert;
    private Timestamp date_insert;

    @OneToOne(cascade = CascadeType.ALL)
    @MapsId("idenelev")
    @JoinColumn(name = "idenelev")
    private Eleve eleve;

    @ManyToOne
    @JoinColumn(name = "codeperiexam",
            foreignKey = @jakarta.persistence.ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private Periexam periexam;



}


