package org.slimarafa.svs_eleve.mappers;

import org.slimarafa.svs_eleve.dtos.EleveDTO;
import org.slimarafa.svs_eleve.entities.Eleve;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
public class EleveMapperImpl {
    public EleveDTO fromEleve(Eleve eleve){
        EleveDTO eleveDTO= new EleveDTO();
        BeanUtils.copyProperties(eleve,eleveDTO);
        return  eleveDTO;
    }
    public Eleve fromEleveDTO(EleveDTO eleveDTO){
        Eleve eleve= new Eleve();
        BeanUtils.copyProperties(eleveDTO,eleve);
        return eleve;
    }
}
