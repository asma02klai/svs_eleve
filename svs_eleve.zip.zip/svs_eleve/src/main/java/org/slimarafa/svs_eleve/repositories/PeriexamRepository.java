package org.slimarafa.svs_eleve.repositories;

import org.slimarafa.svs_eleve.entities.Resultat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PeriexamRepository extends JpaRepository<Resultat, String> {

    @Query("SELECT r FROM Resultat r WHERE r.codeperiexam = :codeperiexam AND r.idenelev = :idenelev")

            Resultat getEleveByResultat(String idenelev, String codeperiexam);



}
