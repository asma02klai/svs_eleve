package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Causabse {
    @Id
    @Column(name = "codecausabse")
    private String codecausabse;

    @Column(name = "libecausabsear")
    private String libecausabsear;

    @Column(name = "libecausabsefr")
    private String libecausabsefr;

    @Column(name = "codecausabsesy")
    private String codecausabsesy;

    // Constructeurs, getters et setters

    public Causabse() {
    }

    public String getCodecausabse() {
        return codecausabse;
    }

    public void setCodecausabse(String codecausabse) {
        this.codecausabse = codecausabse;
    }

    public String getLibecausabsear() {
        return libecausabsear;
    }

    public void setLibecausabsear(String libecausabsear) {
        this.libecausabsear = libecausabsear;
    }

    public String getLibecausabsefr() {
        return libecausabsefr;
    }

    public void setLibecausabsefr(String libecausabsefr) {
        this.libecausabsefr = libecausabsefr;
    }

    public String getCodecausabsesy() {
        return codecausabsesy;
    }

    public void setCodecausabsesy(String codecausabsesy) {
        this.codecausabsesy = codecausabsesy;
    }
}
