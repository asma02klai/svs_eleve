package org.slimarafa.svs_eleve.repositories;

import org.slimarafa.svs_eleve.entities.Eleve;
import org.slimarafa.svs_eleve.entities.Sanction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EleveRepository extends
        JpaRepository<Eleve,String> {

    @Query("SELECT e FROM Eleve e WHERE e.idenelev = :idenelev")
    Eleve findByIdenelev(@Param("idenelev") String idenelev);

    Eleve getByIdenelev(String idenelev);
}