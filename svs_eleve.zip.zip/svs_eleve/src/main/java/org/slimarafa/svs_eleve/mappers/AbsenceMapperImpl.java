package org.slimarafa.svs_eleve.mappers;

import org.slimarafa.svs_eleve.dtos.AbsenceDTO;
import org.slimarafa.svs_eleve.entities.Absence;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
public class AbsenceMapperImpl {
    public AbsenceDTO toDTO(Absence entity) {
        AbsenceDTO dto = new AbsenceDTO();
        BeanUtils.copyProperties(entity, dto);
        return dto;
    }

    public Absence toEntity(AbsenceDTO dto) {
        Absence entity = new Absence();
        BeanUtils.copyProperties(dto, entity);
        return entity;
    }
}
