package org.slimarafa.svs_eleve.repositories;

import org.slimarafa.svs_eleve.entities.Typecaussanc;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TypecaussancRepository extends JpaRepository<Typecaussanc, String> {
}
