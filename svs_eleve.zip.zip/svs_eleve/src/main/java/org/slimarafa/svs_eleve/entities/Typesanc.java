package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Typesanc {
  @Id
     private String codetypesanc;
     private String codecatecaussanc ;
     private String libetypesancar;
     private String libetypesancfr;


    @OneToMany(mappedBy = "typesanc")
    private List<Sanction> sanctions;



}
