package org.slimarafa.svs_eleve.web;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slimarafa.svs_eleve.dtos.SanctionDTO;
import org.slimarafa.svs_eleve.exceptions.SanctionNotFoundException;
import org.slimarafa.svs_eleve.services.SanctionService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sanctions")
@AllArgsConstructor
@Slf4j
public class SanctionRestController {
    private final SanctionService sanctionService;

    @GetMapping("/{idenelev}")
    public List<SanctionDTO> getSanctionsByEleve
            (@PathVariable String idenelev) throws SanctionNotFoundException {
        return sanctionService.getSanctionsByEleve(idenelev);
   }

    // ✅ CREATE
    @PostMapping
    public SanctionDTO saveSanction(
            @RequestBody SanctionDTO sanctionDTO) {
        return sanctionService.saveSanction(sanctionDTO);
    }


    // ✅ UPDATE
    @PutMapping("/{numesanc}")
    public SanctionDTO updateSanction(
            @PathVariable String numesanc,
            @RequestBody SanctionDTO sanctionDTO) {
        sanctionDTO.setNumesanc(numesanc);
        return sanctionService.updateSanction(sanctionDTO);
    }

    // ✅ DELETE
    @DeleteMapping("/{numesanc}")
    public ResponseEntity<Void> deleteSanction(@PathVariable String numesanc) {
        sanctionService.deleteSanction(numesanc);
        return ResponseEntity.noContent().build();
    }
}

