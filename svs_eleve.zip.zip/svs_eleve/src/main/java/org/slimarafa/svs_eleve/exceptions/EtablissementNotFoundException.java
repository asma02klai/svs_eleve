package org.slimarafa.svs_eleve.exceptions;

public class EtablissementNotFoundException extends Throwable {
    public EtablissementNotFoundException(String s) {
        super(s);
    }
}
