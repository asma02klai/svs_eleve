package org.slimarafa.svs_eleve.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@IdClass(InscriptionId.class)
public class Inscription {
    @Id
    private  String idenelev;
    @Id
    private  String annescol;

    @OneToOne(cascade = CascadeType.ALL)
    @MapsId("idenelev")
    @JoinColumn(name="idenelev")
    private Eleve eleve;

    @ManyToOne
    @JoinColumn(name = "codeclas")
    private  Classe classe;

    @ManyToOne
    @JoinColumns({
            @JoinColumn(name = "codeetab", referencedColumnName = "codeetab", insertable = false, updatable = false),
            @JoinColumn(name = "codetypeetab", referencedColumnName = "codetypeetab", insertable = false, updatable = false),
    })
    private Etablissement etabInscri;

    private  String numeordr;
    private  String etatinsc;


}
