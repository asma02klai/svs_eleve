package org.slimarafa.svs_eleve.services;

import jakarta.validation.Valid;
import org.slimarafa.svs_eleve.dtos.EleveDTO;
import org.slimarafa.svs_eleve.exceptions.EleveNotFoundException;

import java.util.List;

public interface EleveService {
    List<EleveDTO> listEleves();

    EleveDTO getEleve(String eleveId) throws EleveNotFoundException;

    EleveDTO saveEleve(EleveDTO eleveDTO);

    EleveDTO updateEleve(EleveDTO eleveDTO);


    void deleteEleve(String eleveId);
}
