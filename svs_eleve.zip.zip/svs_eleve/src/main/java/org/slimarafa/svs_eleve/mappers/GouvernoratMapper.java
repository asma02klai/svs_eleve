package org.slimarafa.svs_eleve.mappers;

import org.slimarafa.svs_eleve.dtos.GouvernoratDTO;
import org.slimarafa.svs_eleve.entities.Gouvernorat;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
public class GouvernoratMapper {
    public GouvernoratDTO fromGouvernorat(Gouvernorat gouvernorat){
        GouvernoratDTO gouvernoratDTO= new GouvernoratDTO();
        BeanUtils.copyProperties(gouvernorat,gouvernoratDTO);
        return gouvernoratDTO;
    }

    public Gouvernorat fromGouvernoratDTO(GouvernoratDTO gouvernoratDTO){
        Gouvernorat gouv=new Gouvernorat();
        BeanUtils.copyProperties(gouvernoratDTO,gouv);
        return gouv;
    }
}
