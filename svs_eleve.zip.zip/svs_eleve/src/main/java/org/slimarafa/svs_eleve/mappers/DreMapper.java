package org.slimarafa.svs_eleve.mappers;

import lombok.AllArgsConstructor;
import org.slimarafa.svs_eleve.dtos.DreDTO;
import org.slimarafa.svs_eleve.entities.Dre;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class DreMapper {
    private GouvernoratMapper gouvernoratMapper;
    public DreDTO fromDre(Dre dre){
        DreDTO dreDTO = new DreDTO();
        BeanUtils.copyProperties(dre,dreDTO);
        dreDTO.setGouvernoratDTO(gouvernoratMapper.fromGouvernorat(dre.getGouvernorat()));
        return dreDTO;
    }

    public Dre fromDreDTO(DreDTO dreDTO){
        Dre dre = new Dre();
        BeanUtils.copyProperties(dreDTO,dre);
        dre.setGouvernorat(gouvernoratMapper.fromGouvernoratDTO(dreDTO.getGouvernoratDTO()));
        return dre;
    }
}
