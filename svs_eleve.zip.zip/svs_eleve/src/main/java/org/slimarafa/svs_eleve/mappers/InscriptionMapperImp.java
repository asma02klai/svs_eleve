package org.slimarafa.svs_eleve.mappers;


import lombok.AllArgsConstructor;
import org.slimarafa.svs_eleve.dtos.InscriptionDTO;
import org.slimarafa.svs_eleve.entities.Inscription;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class InscriptionMapperImp {
    private EleveMapperImpl eleveMpper;
    private ClasseMapperImpl classeMapper;
    private EtablissementMapper etabMapper;

    public InscriptionDTO fromInscription(Inscription inscription) {
        InscriptionDTO inscriptionDTO = new InscriptionDTO();
        BeanUtils.copyProperties(inscription, inscriptionDTO);
        inscriptionDTO.setEleveDTO(eleveMpper.fromEleve(inscription.getEleve()));
        inscriptionDTO.setClasseDTO(classeMapper.fromClasse(inscription.getClasse()));
        inscriptionDTO.setEtabInscriDto(etabMapper.fromEtablissement(inscription.getEtabInscri()));
        return inscriptionDTO;
    }

    public Inscription fromInscriptionDTO(InscriptionDTO inscriptionDTO) {
        Inscription inscription = new Inscription();
        BeanUtils.copyProperties(inscriptionDTO, inscription);
        inscription.setEleve(eleveMpper.fromEleveDTO(inscriptionDTO.getEleveDTO()));
        inscription.setClasse(classeMapper.fromClasseDTO(inscriptionDTO.getClasseDTO()));
        inscription.setEtabInscri(etabMapper.fromEtablissementDTO(inscriptionDTO.getEtabInscriDto()));
        return inscription;
    }
}
