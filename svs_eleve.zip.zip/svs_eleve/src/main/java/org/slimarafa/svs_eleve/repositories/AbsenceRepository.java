package org.slimarafa.svs_eleve.repositories;


import org.slimarafa.svs_eleve.entities.Absence;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AbsenceRepository extends JpaRepository<Absence, String> {
    List<Absence> findByIdenelev(String idenelev);
}

