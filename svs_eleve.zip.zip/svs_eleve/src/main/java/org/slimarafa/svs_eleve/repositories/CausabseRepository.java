package org.slimarafa.svs_eleve.repositories;

import org.slimarafa.svs_eleve.entities.Causabse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CausabseRepository extends JpaRepository<Causabse, String> {
}

