package org.slimarafa.svs_eleve.web;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slimarafa.svs_eleve.dtos.EleveDTO;
import org.slimarafa.svs_eleve.entities.Eleve;
import org.slimarafa.svs_eleve.exceptions.EleveNotFoundException;
import org.slimarafa.svs_eleve.services.EleveService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
//import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@Slf4j

public class EleveRestController {
    private EleveService eleveService;


    @GetMapping("eleves")
    public List<EleveDTO> eleves() {
        return eleveService.listEleves();
    }

    @GetMapping("eleves/{id}")
    public EleveDTO getEleve(@PathVariable(name="id") String eleveId) throws EleveNotFoundException {
        return eleveService.getEleve(eleveId);
    }

@GetMapping("/csrf-token")
    public CsrfToken getCsrfToken(HttpServletRequest request) {
        return (CsrfToken) request.getAttribute("_csrf");

    }

    @PostMapping("/eleves")
    public ResponseEntity<EleveDTO> createEleve(@RequestBody @Valid EleveDTO eleveDTO) {
        EleveDTO created = eleveService.saveEleve(eleveDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }


    @PutMapping("/eleves/{eleveId}")
    public EleveDTO updateEleve(@PathVariable Long eleveId, @RequestBody EleveDTO eleveDTO){
        eleveDTO.setId(eleveId);
        return eleveService.updateEleve(eleveDTO);}

        @DeleteMapping("/eleves/{id}")
        public void deleteEleve(@PathVariable String eleveId){
            eleveService.deleteEleve(eleveId);
        }
    }

