package org.slimarafa.svs_eleve.services;
import org.slimarafa.svs_eleve.dtos.SanctionDTO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public interface SanctionService {
    List<SanctionDTO> getSanctionsByEleve(String idenelev) ;

    SanctionDTO saveSanction(SanctionDTO sanctionDTO);

    SanctionDTO updateSanction(SanctionDTO sanctionDTO);

    void deleteSanction(String numesanc);
}


