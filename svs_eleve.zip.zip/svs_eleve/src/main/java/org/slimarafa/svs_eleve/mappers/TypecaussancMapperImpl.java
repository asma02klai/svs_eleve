package org.slimarafa.svs_eleve.mappers;
import org.slimarafa.svs_eleve.dtos.TypecaussancDTO;
import org.slimarafa.svs_eleve.entities.Typecaussanc;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

@Component
public class TypecaussancMapperImpl {

    public TypecaussancDTO fromTypecaussanc(Typecaussanc typecaussanc){
        TypecaussancDTO typecaussancDTO = new TypecaussancDTO();
//        typecaussancDTO.setCodetypecaussanc(typecaussanc.getCodetypecaussanc());
//      typecaussancDTO.setLibetypecaussancfr(typecaussanc.getLibetypecaussancfr());
       BeanUtils.copyProperties(typecaussanc, typecaussancDTO);
         return typecaussancDTO;
    }

   public Typecaussanc fromTypecaussancDTO(TypecaussancDTO typecaussancDTO){
        Typecaussanc typecaussanc = new Typecaussanc();
        BeanUtils.copyProperties(typecaussancDTO,typecaussanc);
        return typecaussanc;
    }


}