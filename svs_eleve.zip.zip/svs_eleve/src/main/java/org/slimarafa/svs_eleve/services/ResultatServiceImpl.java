package org.slimarafa.svs_eleve.services;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slimarafa.svs_eleve.dtos.ResultatDTO;
import org.slimarafa.svs_eleve.entities.*;
import org.slimarafa.svs_eleve.exceptions.ResultatNotFoundException;
import org.slimarafa.svs_eleve.mappers.ResultatMapperImpl;
import org.slimarafa.svs_eleve.repositories.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
@Transactional
@Slf4j
@AllArgsConstructor
public class ResultatServiceImpl implements ResultatService {

    private ResultatRepository resultatRepository;
    private ResultatMapperImpl resultatMapper;

    @Override
    public List<ResultatDTO> getElevesByResultat(String idenelev, String codeperiexam) {
        Resultat resultat = resultatRepository.getByIdenelevAndCodeperiexam(idenelev, codeperiexam).
              orElseThrow(() -> new ResultatNotFoundException("Resultat n'existe pas"));
        return List.of(resultatMapper.fromResultat(resultat));
    }

}
