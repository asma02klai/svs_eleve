package org.slimarafa.svs_eleve.mappers;

import org.slimarafa.svs_eleve.dtos.CateabseDTO;
import org.slimarafa.svs_eleve.entities.Cateabse;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
public class CateabseMapperImpl {
    public CateabseDTO toDTO(Cateabse entity) {
        CateabseDTO dto = new CateabseDTO();
        BeanUtils.copyProperties(entity, dto);
        return dto;
    }

    public Cateabse toEntity(CateabseDTO dto) {
        Cateabse entity = new Cateabse();
        BeanUtils.copyProperties(dto, entity);
        return entity;
    }

}
