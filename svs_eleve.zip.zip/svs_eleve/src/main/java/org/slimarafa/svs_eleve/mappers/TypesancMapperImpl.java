package org.slimarafa.svs_eleve.mappers;
import org.slimarafa.svs_eleve.dtos.TypesancDTO;
import org.slimarafa.svs_eleve.entities.Typesanc;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

@Component
public class TypesancMapperImpl {
    public TypesancDTO fromTypesanc(Typesanc typesanc){
        TypesancDTO typesancDTO = new TypesancDTO();
//                typesancDTO.setCodetypesanc(typesanc.getCodetypesanc());
//                typesancDTO.setLibetypesancfr(typesanc.getLibetypesancfr());
       BeanUtils.copyProperties(typesanc, typesancDTO);
        return typesancDTO;
    }

    public Typesanc fromTypesancDTO(TypesancDTO typesancDTO){
        Typesanc typesanc = new Typesanc();
        BeanUtils.copyProperties(typesancDTO,typesanc);
       return typesanc;
    }
}