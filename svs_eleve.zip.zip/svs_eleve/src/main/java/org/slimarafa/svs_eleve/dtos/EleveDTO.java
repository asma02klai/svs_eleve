package org.slimarafa.svs_eleve.dtos;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.slimarafa.svs_eleve.entities.Etablissement;
import org.slimarafa.svs_eleve.entities.Inscription;
import org.slimarafa.svs_eleve.entities.Nationalite;
import org.slimarafa.svs_eleve.entities.Sexe;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class EleveDTO {

    private String idenelev;
    private String prenelevar;
    private String nomelevar;
    private String nomelevfr;
    private String prenelevfr;
    private LocalDate datenaiselev;
    private String lieunaiselev;
    private String dateentretab;
    private String nomtute;
    private String prentute;
    private String lienpare;
    private String ruetute;
    private String codeposttute;
    private String villtute;
    private String teletute;
    private String datesortetab;


    private InscriptionDTO inscriptionDTO;


    public void setId(Long eleveId) {
        return;
    }
}
