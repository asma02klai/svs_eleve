INSERT INTO public.users(id, username, password) VALUES
(1, 'navin', 'n@123'),
(2, 'sushil', 's@123');


