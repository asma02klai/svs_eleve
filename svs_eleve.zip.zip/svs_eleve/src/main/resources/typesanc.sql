INSERT INTO public.typesanc(codetypesanc,codecatecaussanc,libetypesancar,libetypesancfr) VALUES ('11', '1', 'إنــــــــذار', 'Avertissement');
INSERT INTO public.typesanc(codetypesanc,codecatecaussanc,libetypesancar,libetypesancfr) VALUES ('12', '1', 'توبيخ', 'Blâme');
INSERT INTO public.typesanc(codetypesanc,codecatecaussanc,libetypesancar,libetypesancfr) VALUES ('13', '1', 'مذاكرة تكميلية', 'Révision compl.');
INSERT INTO public.typesanc(codetypesanc,codecatecaussanc,libetypesancar,libetypesancfr) VALUES ('21', '2', 'إنــــــــذار', 'Avertissement (professeur/directeur)');
INSERT INTO public.typesanc(codetypesanc,codecatecaussanc,libetypesancar,libetypesancfr) VALUES ('22', '2', 'الرفــت المؤقت:1-3 أيــام', 'Renvoi provisoire  (1 à 3 j)');
INSERT INTO public.typesanc(codetypesanc,codecatecaussanc,libetypesancar,libetypesancfr)VALUES ('23', '2', 'الرفــت المؤقت: 4- 15 يوما', 'Renvoi provisoire ( 4 à 15 j)');
INSERT INTO public.typesanc(codetypesanc,codecatecaussanc,libetypesancar,libetypesancfr)VALUES ('24', '2', 'الرفت النهائي من المؤســسة', 'Renvoi définitif de l''établissement');
INSERT INTO public.typesanc(codetypesanc,codecatecaussanc,libetypesancar,libetypesancfr) VALUES ('25', '2', 'الرفت النهــائي من جميع المؤسـسات', 'Renvoidéfinitif de tous les établissemen');
