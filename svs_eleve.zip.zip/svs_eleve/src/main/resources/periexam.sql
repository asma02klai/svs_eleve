
INSERT INTO public.periexam (codeperiexam,libeperiexamar,libeperiexamfr,coefperiexam) VALUES
('31', 'الثلاثي الأول', '1er trimestre', '1');
('32', 'الثلاثي الثاني', '2ème trimestre', '2');
('33', 'الثلاثي الثالث', '3ème trimestre', '2');
('61', 'السداسي الأول', '1er semestre', '1');
('62', 'السداسي الثاني', '2ème semestre', '2');
('99', 'السنوي', 'annuel', '1');
