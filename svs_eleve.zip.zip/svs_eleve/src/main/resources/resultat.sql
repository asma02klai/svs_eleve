INSERT INTO resultat (idenelev,codeperiexam,moyeperiexam,rangperiexam,codedecicons,codesectori,obsecons,
                      codeprix,moyeexamnati,codementexam,codeetab,codecondassi,datetransfert,etattransfert
    ,date_insert) VALUES
('010957141117', '31', '09.35', '20', null, null, null, null, null, null, '614004', '1', null, null, '2025-01-06 15:22:34.805161');
